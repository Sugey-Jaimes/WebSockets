var ws = new WebSocket("ws://localhost:8181");

ws.onopen = function(e){
    console.log('Conexión hacia el servidor abierta');
};

ws.onmessage = function(message){
    console.log('Recibo resultado');
    console.log(message.data);
    document.getElementById('valor_resultado').innerHTML = message.data;
}

function realizarOperacion(){
    let operacion = document.getElementById("operacion").value;
    let num_uno = document.getElementById("num_uno").value;
    let num_dos = document.getElementById("num_dos").value;
    const data = {
        operacion: operacion,
        num_uno: num_uno,
        num_dos: num_dos
    }
    ws.send(JSON.stringify(data));
}