var WebSocketServer = require('ws').Server,
wss = new WebSocketServer({port:8181});

console.log('Servidor iniciado');
wss.on('connection', function(ws){
    console.log('Cliente conectado');
    ws.on('message', function(message){
        var object = JSON.parse(message);
        switch(object.operacion){
            case 'suma':{
                console.log('Realizando suma');
                var resultado = parseFloat(object.num_uno)+parseFloat(object.num_dos);
                resultado = resultado.toFixed(2);
                ws.send(resultado);
            }break;
            case 'resta':{
                console.log('Realizando resta');
                var resultado = object.num_uno - object.num_dos;
                resultado = resultado.toFixed(2);
                ws.send(resultado);
            }break;
            case 'multi':{
                console.log('Realizando multiplicacion');
                var resultado = object.num_uno * object.num_dos;
                resultado = resultado.toFixed(2);
                ws.send(resultado);
            }break;
            case 'div':{
                console.log('Realizando division');
                var resultado = object.num_uno / object.num_dos;
                resultado = resultado.toFixed(2);
                ws.send(resultado);
            }break;
        }
    });
});